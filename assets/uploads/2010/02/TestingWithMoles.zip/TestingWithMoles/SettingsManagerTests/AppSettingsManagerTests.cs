﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SettingsManager;
using System.Configuration.Moles;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Moles.Framework;

[assembly:MoledType(typeof(System.Configuration.ConfigurationManager))]
namespace SettingsManagerTests
{
    [TestClass]
    public class AppSettingsManagerTests
    {
        /// <summary>
        /// Test that checks if the method returns the 
        /// appropriate value from AppSettings.
        /// </summary>
        [TestMethod]
        public void ExtractAppSettingValidConfigurationOk()
        {
            Assert.AreEqual<string>(
                "myvalue", 
                AppSettingsManager.ExtractAppSetting(), 
                "Invalid value in AppSettings");
        }

        /// <summary>
        /// Test that checks if the method throws an exception if 
        /// the AppSettings is empty.
        /// </summary>
        [TestMethod]
        [HostType("Moles")]
        [ExpectedException(typeof(ConfigurationErrorsException))]
        public void ExtractAppSettingEmptySettingsExceptionExpected()
        {
            MConfigurationManager.AppSettingsGet = () => new NameValueCollection();
            AppSettingsManager.ExtractAppSetting();
        }
    }
}
