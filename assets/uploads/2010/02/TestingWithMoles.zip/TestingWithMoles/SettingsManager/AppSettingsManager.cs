﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace SettingsManager
{
    /// <summary>
    /// Class to manage app settings.
    /// </summary>
    public class AppSettingsManager
    {
        /// <summary>
        /// Retrieves app setting by its key.
        /// </summary>
        /// <returns>Value in the settings.</returns>
        public static string ExtractAppSetting()
        {
            string key = "myKey";
            if (ConfigurationManager.AppSettings.AllKeys.Contains(key) == false ||
                string.IsNullOrEmpty(ConfigurationManager.AppSettings[key]) == true)
            {
                throw new ConfigurationErrorsException("Key not found");
            }

            return ConfigurationManager.AppSettings[key];
        }
    }
}
