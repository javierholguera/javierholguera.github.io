﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloWorldService
{
    /// <summary>
    /// Service that says hello world.
    /// </summary>
    [ServiceContract]
    public interface IHelloWorld
    {
        /// <summary>
        /// Gets "Hello World from X", where X is the name parameter.
        /// </summary>
        /// <param name="name">Who says hello.</param>
        /// <returns>String with hello world message.</returns>
        [OperationContract]
        string GetHelloWorld(string name);
    }
}
