﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloWorldService
{
    public class HelloWorld : IHelloWorld
    {
        /// <summary>
        /// Gets "Hello World from X", where X is the name parameter.
        /// </summary>
        /// <param name="name">Who says hello.</param>
        /// <returns>String with hello world message.</returns>
        public string GetHelloWorld(string name)
        {
            return string.Format(
                "Hello world from {0} - Request from {1}", name, OperationContext.Current.Channel.LocalAddress);
        }
    }
}
