﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ServiceHoster
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceHost host = new ServiceHost(
                typeof(HelloWorldService.HelloWorld),
                new Uri("http://localhost:9999/HelloWorldService"),
                new Uri("net.tcp://localhost:9998/HelloWorldService")))
            {
                host.AddDefaultEndpoints();
                host.Open();

                foreach (ServiceEndpoint endpoint in host.Description.Endpoints)
                {
                    Console.WriteLine(
                        "Endpoint: Address {0}, Binding {1}, Contract = {2}",
                        endpoint.Address,
                        endpoint.Binding,
                        endpoint.Contract);
                }

                Console.WriteLine("Push <ENTER>");
                Console.ReadLine();
            }
        }
    }
}
