﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceReference.ServiceClient proxy = new ServiceReference.ServiceClient())
            {
                Console.WriteLine("Calling the remote server...");
                proxy.SendData(int.MaxValue);
                Console.WriteLine("Remote server called...");
                Console.ReadLine();
            }
        }
    }
}
