﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Configuration;

namespace OneWayService
{
    /// <summary>
    /// Custom behavior extension element for the custom endpoint behavior.
    /// </summary>
    public class MyBehaviorExtensionElement : BehaviorExtensionElement
    {
        public override Type BehaviorType
        {
            get { return typeof(MyEndpointBehavior); }
        }

        protected override object CreateBehavior()
        {
            return new MyEndpointBehavior();
        }
    }
}
