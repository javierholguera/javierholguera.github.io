﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace OneWayService
{
    /// <summary>
    /// One Way Service.
    /// </summary>
    [ServiceContract]
    public interface IService
    {
        /// <summary>
        /// OneWay method.
        /// </summary>
        /// <param name="value">Value to send.</param>
        [OperationContract(IsOneWay=true)]
        void SendData(int value);
    }
}
