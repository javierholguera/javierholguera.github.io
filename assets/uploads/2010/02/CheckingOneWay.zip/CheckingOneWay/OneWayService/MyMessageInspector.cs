﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;

namespace OneWayService
{
    /// <summary>
    /// My message inspector class.
    /// </summary>
    public class MyMessageInspector : IDispatchMessageInspector
    {
        public object AfterReceiveRequest(
            ref System.ServiceModel.Channels.Message request, 
            System.ServiceModel.IClientChannel channel, 
            System.ServiceModel.InstanceContext instanceContext)
        {
            // Crear un "replicador" de mensajes y usarlo para obtener una copia del mismo
            MessageBuffer buffer = request.CreateBufferedCopy(int.MaxValue);
            string messageContent = buffer.CreateMessage().GetReaderAtBodyContents().ReadOuterXml();
            System.Diagnostics.Debug.WriteLine(messageContent);
            
            // Asignar una copia sin leer del mensaje en request, para que otros 
            // componentes del pipeline de WCF puedan leerlo sin fallar.
            request = buffer.CreateMessage();

            // Devolver null como resultado, que será lo que reciba el metodo BeforeSendReply
            // en el parámetro correlationState
            return null;
        }

        public void BeforeSendReply(
            ref System.ServiceModel.Channels.Message reply, 
            object correlationState)
        {
        }
    }
}
